Depends/ReadMe.txt
------------------

This project is "depends" and is code from MSJ (now MSDN) in 1997.  I appreciate and respect the code provided by Matt Pietrik.  I have made the following changes:
1) Added the -q option
2) Added the MSVC build environment (for 32bit and 64bit builds)
3) Modified the default response to report 1 and 2.

The projects builds depends32.exe and depends64.exe which are used by runner32.bat and runner64.bat to test dependancies post build.

Robin Mills
http://clanmills.com
2011-01-02
