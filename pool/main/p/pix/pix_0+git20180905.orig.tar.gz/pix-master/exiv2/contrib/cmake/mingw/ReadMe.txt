See <exiv2dir>/README-CMAKE and <exiv2dir>/TODO-CMAKE for an explanation
