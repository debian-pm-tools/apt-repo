
#include <hardware/sensors.h>

int main()
{
    return 0;
}
