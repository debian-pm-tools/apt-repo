sensorfw-iioadaptor
===================

Industrial I/O plugin for SensorFW

WIP.
 * working accelerometer
  - data is wrong

