#ifndef DEPRECATED_HEADER_QtSql_qsql_h
#define DEPRECATED_HEADER_QtSql_qsql_h
#if defined(__GNUC__)
#  warning Header <QtSql/qsql.h> is deprecated. Please include <QtSql/qtsqlglobal.h> instead.
#elif defined(_MSC_VER)
#  pragma message ("Header <QtSql/qsql.h> is deprecated. Please include <QtSql/qtsqlglobal.h> instead.")
#endif
#include <QtSql/qtsqlglobal.h>
#if 0
#pragma qt_no_master_include
#endif
#endif
