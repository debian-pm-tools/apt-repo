This is dummy english dictionary which knows only following words:

* I
* you
* he
* she
* it
* we
* they
* love
* loves
* qt

Also each of words above can start with 'q' for example:

* qI
