QML Plane
=========

![QMLPlane](http://i.imgur.com/hmPVcqb.png)

This demo game showcases the capabilities of Qt Quick 2. The graphics in the game are entirely vector, so it will look good on any device.

## DOWNLOAD

* [Android](https://play.google.com/store/apps/details?id=com.wearyinside.qmlplane)

## DEPENDENCIES

* QML Box2D plugin: https://github.com/qml-box2d/qml-box2d

## LICENSE

Copyright (C) 2014-2015 [Oleg Yadrov](https://linkedin.com/in/olegyadrov)

Distributed under the Apache Software License, Version 2.
