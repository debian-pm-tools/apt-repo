Droid AudioFlinger Glue
=======================

Based on work by Mohammed Hassan <mohammed.hassan@jolla.com>

Simple service that replaces AudioFlinger and library for
forwarding calls made to custom AudioFlinger to client.
